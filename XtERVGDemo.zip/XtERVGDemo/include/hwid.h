#ifndef _HWID_H
#define _HWID_H

#ifdef __cplusplus
	extern "C" {
#endif

int read_hwid(void);

#ifdef __cplusplus
	}
#endif

#endif
